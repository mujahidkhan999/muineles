package com.scotiabank.homefinancingadvisors;

import java.io.IOException;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.Cookie;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.scotiabank.json.ReadJsonObject;
import com.scotiabank.pages.HomePage;
import com.scotiabank.testbase.TestBase;

public class TC001_VerifySearchByLastName extends TestBase {

  HomePage homepage;

  public static final Logger log = Logger.getLogger(TC001_VerifySearchByLastName.class.getName());

  @BeforeTest
  public void setup() throws IOException {
    init();
  }

  @Test
  public void VerifySearchByLastName() {
    log("------------------- Starting VerifySearchByLastName Test -------------------");
    homepage = new HomePage(driver);
    homepage.refreshPage();
    homepage.clickHomeFinancingAdvisorsLink();
    homepage.enterLastName();
    homepage.clickGo();
    
    Set<Cookie> cookies = driver.manage().getCookies();
    
    ReadJsonObject r = new ReadJsonObject();
    r.getJson(cookies);
    
   Assert.assertTrue(homepage.getAdvisorName().contains("Smith"));
    log("------------------- Ending VerifySearchByLastName Test -------------------");
  }

 /* @AfterClass
  public void endTest() {
    //driver.quit();
  }*/
  
}
