package com.scotiabank.homefinancingadvisors;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_01 {

	@Test
	public void testWithLastName() {

		WebDriver driver = new FirefoxDriver();

		driver.get("http://maps.scotiabank.com/");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		driver.findElement(By.xpath(".//*[@id='tab2']/span[1]")).click();

		driver.findElement(By.xpath(".//*[@id='name']")).sendKeys("Smith");

		driver.findElement(By.xpath(".//*[@id='hfa-lastname-go']/span")).click();

		Set<Cookie> cookies = driver.manage().getCookies();

		try {

			// create URL instance
			URL url = new URL("http://maps.scotiabank.com/mslt");
			// URL url = new
			// URL("http://maps.scotiabank.com/mslt?hfa-lastname=Smith&selProvinceSpec-hfa=&citySpec=&slang=&language=en");
			
			//open http utl connection
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			
			//setting request method
			connection.setRequestMethod("POST");
			
			// set request properties
			connection.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01");
			connection.setRequestProperty("Accept-Encoding", "gzip, deflate");
			connection.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
			connection.setRequestProperty("Connection", "keep-alive");
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			connection.setRequestProperty("Host", "maps.scotiabank.com");
			connection.setRequestProperty("Origin", "maps.scotiabank.com");
			connection.setRequestProperty("Referer", "maps.scotiabank.com");
			connection.setRequestProperty("X-Requested-With", "XMLHttpRequest");

			StringBuilder sb = new StringBuilder();
			//build cookies
			for (Cookie cookie : cookies) {
				sb.append(cookie.getName() + "=" + cookie.getValue() + ";");

			}
			connection.setRequestProperty("Cookie", sb.toString().substring(0, sb.toString().length() - 1));

			
			// check response code
			if (connection.getResponseCode() != 200) {
				throw new RuntimeException(" HTTP error code : " + connection.getResponseCode());
			}

			Scanner scan = new Scanner(url.openStream());
			String entireResponse = new String();
			while (scan.hasNext())
				entireResponse += scan.nextLine();

			System.out.println("Response : " + entireResponse);

			scan.close();

			JSONObject obj = new JSONObject(entireResponse);
			String responseCode = obj.getString("status");
			System.out.println("status : " + responseCode);

			JSONArray arr = obj.getJSONArray("data");
			for (int i = 0; i < arr.length(); i++) {
				String specialistNUm = arr.getJSONObject(i).getString("SPECIALISTNUM");
				System.out.println("SPECIALISTNUM : " + specialistNUm);

				if (specialistNUm.equalsIgnoreCase("4503")) {
					System.out.println("SPECIALISTNUM is as Expected");
				} else {
					System.out.println("SPECIALISTNUM is not as Expected");
				}
			}

			connection.disconnect();
		} catch (Exception e) {

			e.printStackTrace();

		}

	}

}
