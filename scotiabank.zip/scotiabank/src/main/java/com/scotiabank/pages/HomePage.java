package com.scotiabank.pages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.scotiabank.testbase.TestBase;

public class HomePage extends TestBase {

	public static final Logger log = Logger.getLogger(HomePage.class.getName());

	WebDriver driver;

	@FindBy(xpath = ".//*[@id='tab2']/span[1]")
	WebElement financeTab;

	@FindBy(xpath = ".//*[@id='name']")
	WebElement lastName;

	@FindBy(xpath = ".//*[@id='hfa-lastname-go']/span")
	WebElement goButton;

	

	public HomePage(final WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickHomeFinancingAdvisorsLink() {

		financeTab.click();

	}

	public void enterLastName() {
		lastName.sendKeys("Smith");
	}

	public void clickGo() {
		goButton.click();
	}


	public void refreshPage() {
		driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	public String getAdvisorName() {
		// TODO Auto-generated method stub
		return driver.findElement(By.xpath(".//*[@id='hfa_3342']/a/span")).getText();
	}
}
