package com.scotiabank.json;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.Cookie;

public class ReadJsonObject {

	public void getJson(Set<Cookie> cookies){
		
		try {
			
			URL url = new URL("http://maps.scotiabank.com/mslt");
			//URL url = new URL("http://maps.scotiabank.com/mslt?hfa-lastname=Smith&selProvinceSpec-hfa=&citySpec=&slang=&language=en");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01");
			conn.setRequestProperty("Accept-Encoding", "gzip, deflate");
			conn.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
			conn.setRequestProperty("Connection", "keep-alive");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			conn.setRequestProperty("Host", "maps.scotiabank.com");
			conn.setRequestProperty("Origin", "maps.scotiabank.com");
			conn.setRequestProperty("Referer", "maps.scotiabank.com");
			
			conn.setRequestProperty("X-Requested-With", "XMLHttpRequest");
		/*	
			Map<String, List<String>> m = conn.getHeaderFields();
			for (Entry<String, List<String>> entry : m.entrySet()) {
				System.out.println(entry.getKey()+"");
				for (String value : entry.getValue()) {
					System.out.println(value);
				}
				
			}*/
			StringBuilder sb = new StringBuilder();
			for (Cookie cookie : cookies) {
				sb.append(cookie.getName()+"="+cookie.getValue()+";");
				
			}
			conn.setRequestProperty("Cookie", sb.toString().substring(0, sb.toString().length()-1));
			
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException(" HTTP error code : " + conn.getResponseCode());
			}

			Scanner scan = new Scanner(url.openStream());
			String entireResponse = new String();
			while (scan.hasNext())
				entireResponse += scan.nextLine();

			System.out.println("Response : " + entireResponse);

			scan.close();

			JSONObject obj = new JSONObject(entireResponse);
			String responseCode = obj.getString("status");
			System.out.println("status : " + responseCode);

			JSONArray arr = obj.getJSONArray("data");
			for (int i = 0; i < arr.length(); i++) {
				String specialistNUm = arr.getJSONObject(i).getString("SPECIALISTNUM");
				System.out.println("SPECIALISTNUM : " + specialistNUm);
				

				if (specialistNUm.equalsIgnoreCase("4503")) {
					System.out.println("SPECIALISTNUM is as Expected");
				} else {
					System.out.println("SPECIALISTNUM is not as Expected");
				}
			}

			conn.disconnect();
		} catch (Exception e) {
		
			e.printStackTrace();

		}

	}
}