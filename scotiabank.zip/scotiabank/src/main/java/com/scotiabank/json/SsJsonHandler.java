package com.scotiabank.json;

/**
 *
 * @author Brynette Stewart, Gerson Lobos, stephen conklin, this class will handle reading the json configuration file located in the root of
 *         caseleniumtest dir tree
 *
 * @date February 12, 2014
 *
 */
import java.io.*;
import java.util.List;

import com.google.gson.Gson;

public class SsJsonHandler<DataObject> {

  private static String jsonFilePath = "jsonConfData.json";

  private static JsonDataObject DataObject = new JsonDataObject();

  // method to verify initial setup
  public String junkMethod() {
    String tstString = "test";
    return tstString;
  }

  public void readJsonFile() {

    Gson gson = new Gson();

    try {
      BufferedReader br = new BufferedReader(new FileReader(jsonFilePath));

      DataObject = gson.fromJson(br, JsonDataObject.class);

    } catch (IOException e) {
      e.printStackTrace();
    }

  }

  public String getURL() {
    return DataObject.getURL();
  }

  public String getEMAIL() {
    return DataObject.getEMAIL();
  }

  public String getPASSWORD() {
    return DataObject.getPASSWORD();
  }

  public List<String> getLIST() {
    return DataObject.getList();
  }
}
