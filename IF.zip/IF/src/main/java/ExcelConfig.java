

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelConfig {

	private static int keyColumn =0;
	private static int valueColumn=1;

	public static Map<String,String> readExcel() throws Exception {
		Map<String,String> map = new HashMap<String,String>();
		String excelFilePath = "Configuration.xlsx";
		String workingDirectory = System.getProperty("user.dir");
		String absoluteFilePath = "";
		absoluteFilePath = workingDirectory + File.separator + excelFilePath;
		//		System.out.println("Final filepath : " + absoluteFilePath);	       
		FileInputStream inputstream = new FileInputStream(new File(excelFilePath));	

		Workbook workbook = new XSSFWorkbook(inputstream);
		Sheet firstSheet = workbook.getSheetAt(0);

		for(int i=1;i<=firstSheet.getLastRowNum();i++)
		{
			Row row = firstSheet.getRow(i);
			if(row !=null) {
				String key = getCellValue(row,keyColumn);
				String value = getCellValue(row,valueColumn);
				map.put(key,value);	
			}
		}
		workbook.close();
		inputstream.close();
		return map;
	}

	private static String getCellValue(Row row, int column) {
		// TODO Auto-generated method stub		
		Cell cell = row.getCell(column);	
		String cellvalue = "";
		if(cell!=null) {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
				cellvalue = cell.getStringCellValue();
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				cellvalue = String.valueOf(cell.getBooleanCellValue());
				break;
			case Cell.CELL_TYPE_NUMERIC:
				cellvalue = String.valueOf(cell.getNumericCellValue());
				break;
			}
		}
		return cellvalue;
	}
}
