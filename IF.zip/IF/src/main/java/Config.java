import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * 
 */

/**
 * @author mamid
 *
 */
public class Config {

	private static int keyColumnn = 0;
	private static int valueColumn = 1;

	/**
	 * @param args
	 */
	public static Map<String, String> readExcel() throws Exception{
		Map<String, String> map = new HashMap<String, String>();
		// change the path accordingly but if you are placing in project then just put as it is
		String excelFilePath = "Configuration.xlsx";
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

		Workbook workbook = new XSSFWorkbook(inputStream);
		//if only 1 sheet then use as below but multiple sheets then use name of sheet method
		Sheet firstSheet = workbook.getSheetAt(0);
		
		for (int i=1; i<= firstSheet.getLastRowNum(); i++) {
			Row row = firstSheet.getRow(i);
			if(row != null) {
				String key = getCellValue(row, keyColumnn);
				String value = getCellValue(row, valueColumn);
				map.put(key, value);
			}
		}
		
		workbook.close();
		inputStream.close();
		return map;
	}

	private static String getCellValue(Row row, int column) {
		Cell cell = row.getCell(column);
		String cellValue = "";
		if(cell!= null) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			cellValue = cell.getStringCellValue();
			break;
		case Cell.CELL_TYPE_BOOLEAN:
			cellValue = String.valueOf(cell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_NUMERIC:
			cellValue = String.valueOf(cell.getNumericCellValue());
			break;
	}
		}
		return cellValue;
	}
}