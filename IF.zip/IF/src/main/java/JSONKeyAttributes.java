

import java.util.Arrays;
import java.util.List;

public class JSONKeyAttributes {
	private String type;
	private String id ;
	private String name;
	private String entityid;	
	private boolean active;
	private String baseURL;	
	private String loggingMode;	
	private String virtualEntityIds[];	
	private String licenseConnectionGroup;
	private String contactInfo[] ;
//	private List<credentials> credentials;
//	private List<spBrowserSso> spBrowserSso;
	
	

}