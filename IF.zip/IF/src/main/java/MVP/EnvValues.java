package MVP;

public class EnvValues {

	String datastoreId,ut,st,et,prod ;

	public EnvValues(String datastoreId, String ut, String st, String et, String prod) {
		super();
		this.datastoreId = datastoreId;
		this.ut = ut;
		this.st = st;
		this.et = et;
		this.prod = prod;
	}

	public String getDatastoreId() {
		return datastoreId;
	}

	public String getUt() {
		return ut;
	}

	public String getSt() {
		return st;
	}

	public String getEt() {
		return et;
	}

	public String getProd() {
		return prod;
	}

	@Override
	public String toString() {
		return "EnvValues [datastoreId=" + datastoreId + ", ut=" + ut + ", st=" + st + ", et=" + et + ", prod=" + prod
				+ "]";
	}

		
}
