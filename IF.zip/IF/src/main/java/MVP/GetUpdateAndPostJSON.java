package MVP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

public class GetUpdateAndPostJSON {

	private static Map<String, String> map ;

	public static void main(String args[]) throws JSONException, Exception {
		try {
			map = ExcelConfig.getConnectorMap();			
			JSONObject jsonobj   = readJsonFromUrl(map.get("GET-URL")+map.get("entityId"));
			
			UpdateJSON.updateJSON(jsonobj);
			
			JSONObject updatedjson = new JSONObject(jsonobj.toString());
			postJSONToURL(updatedjson);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {		
		URL u = new URL(url);		
		HttpURLConnection con = (HttpURLConnection) u.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);
		con.setRequestProperty("entityId", map.get("entityId"));
		con.setRequestProperty("Authorization", map.get("Authorization"));
		con.setRequestProperty("Content-Type", map.get("Content-Type"));	
		con.setRequestProperty("Accept", map.get("Accept"));
		con.setRequestMethod("GET");
		con.setRequestProperty("X-Xsrf-Header", map.get("X-Xsrf-Header"));
		BufferedReader rd = new BufferedReader(new InputStreamReader(con.getInputStream(), Charset.forName("UTF-8")));
		String jsonText = readAll(rd);
		JSONObject json = new JSONObject(jsonText);
		System.out.println("GET JSON from ST is successful : "+json);
		return json;
	}	 


	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public static void postJSONToURL(JSONObject jsonobj) throws IOException, JSONException {

		URL url1 = new URL(map.get("POST-URL"));
		HttpURLConnection connection = (HttpURLConnection) url1.openConnection();		
		connection.setDoOutput(true);
		connection.setRequestProperty("Authorization", map.get("Authorization"));
		connection.setRequestProperty("id", map.get("PUT-ID"));	
		connection.setRequestProperty("Content-Type", map.get("Content-Type"));
		connection.setRequestProperty("X-Xsrf-Header",map.get("X-Xsrf-Header"));
		connection.setRequestMethod("POST");
		String content = jsonobj.getJSONArray("items").get(0).toString();
		System.out.println("POST the updated JSON :" +content);
		OutputStreamWriter osw = new OutputStreamWriter(connection.getOutputStream());
		osw.write(content);
		osw.flush();
		osw.close();
		//		System.err.println(connection.getResponseCode());
		if(connection.getResponseCode()==200) {
			System.out.println("\n" );
			System.out.println(" PUT request is successful");
		}
		if(connection.getResponseCode()==201) {
			System.out.println("\n" );
			System.out.println(" POST request is successful");
		}
	}	 
}

