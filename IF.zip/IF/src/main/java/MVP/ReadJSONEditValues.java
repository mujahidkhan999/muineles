package MVP;

import java.io.File;
import java.io.FileInputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadJSONEditValues implements Map<String, String> {


	private static int keyColumn =0;
	private static int valueColumn=1;

	public static Map<String,String> readExcel() throws Exception {
		Map<String,String> map = new HashMap<String,String>();
		FileInputStream inputstream = new FileInputStream(new File("JSONEditorValues.xlsx"));	

		Workbook workbook = new XSSFWorkbook(inputstream);
		Sheet firstSheet = workbook.getSheetAt(0);

		for(int i=1;i<=firstSheet.getLastRowNum();i++)
		{
			Row row = firstSheet.getRow(i);
			if(row !=null) {
				String key = getCellValue(row,keyColumn);
				String value = getCellValue(row,valueColumn);
				map.put(key,value);	
			}
		}
		workbook.close();
		inputstream.close();
		return map;
	}
	
	public static Map<String,String> getJSONEditMap()  {
		try {
		String connectorName = ExcelConfig.getConnectorName();
		Map<String,String> map = new HashMap<String,String>();
		FileInputStream inputstream = new FileInputStream(new File("JSONEditorValues.xlsx"));	

		 Workbook workbook = new XSSFWorkbook(inputstream);
		 Sheet jsonEditSheet = workbook.getSheetAt(0);

		 Row headerRow = jsonEditSheet.getRow(0);
		int colCount = headerRow.getLastCellNum();
		 int flagTrueColNum = 0;
		 for(int c = 1; c<=colCount; c++) {
			 if(headerRow != null) {
				 String value = getCellValue(headerRow, c);
				 if(connectorName.equalsIgnoreCase(value)) {
					 flagTrueColNum = c;
					 break;
				 }
			 }
		 }

		 for(int i=1;i<=jsonEditSheet.getLastRowNum();i++)
		 {

			 Row row = jsonEditSheet.getRow(i);
			 if(row !=null) {
				 String key = getCellValue(row,keyColumn);
				 String value = getCellValue(row,flagTrueColNum);

				 map.put(key,value);	 


			 }
		 }
		 workbook.close();
		 inputstream.close();
		 return map;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}


	private static String getCellValue(Row row, int column) {
		// TODO Auto-generated method stub		
		Cell cell = row.getCell(column);	
		String cellvalue = "";
		if(cell!=null) {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
				cellvalue = cell.getStringCellValue();
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				cellvalue = String.valueOf(cell.getBooleanCellValue());
				break;
			case Cell.CELL_TYPE_NUMERIC:
				cellvalue = String.valueOf(cell.getNumericCellValue());
				break;
			}
		}
		return cellvalue;
	}

	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean containsKey(Object key) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean containsValue(Object value) {
		// TODO Auto-generated method stub
		return false;
	}

	public String get(Object key) {
		// TODO Auto-generated method stub
		return null;
	}

	public String put(String key, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	public String remove(Object key) {
		// TODO Auto-generated method stub
		return null;
	}

	public void putAll(Map<? extends String, ? extends String> m) {
		// TODO Auto-generated method stub

	}

	public void clear() {
		// TODO Auto-generated method stub

	}

	public Set<String> keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<String> values() {
		// TODO Auto-generated method stub
		return null;
	}

	public Set<Entry<String, String>> entrySet() {
		// TODO Auto-generated method stub
		return null;
	}
public static void main(String[] args) throws Exception {
	Map<String, String> map = getJSONEditMap();
	for (Map.Entry entry : map.entrySet()) {
		System.out.println(entry.getKey()+" "+entry.getValue());
	}
} 
}
