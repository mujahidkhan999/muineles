package MVP;


import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;


public class UpdateJSON {	

	
	private static Map<String, String> editmap =  ReadJSONEditValues.getJSONEditMap() ;	
	
	private static Map<String, EnvValues> dataStoreMap = DataStore.getDataStoreMap();

	public static void updateType(JSONObject jsonobj) throws Exception {		
		if(editmap.get("type")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("type", editmap.get("type"));
		}
	}
	public static void updateid(JSONObject jsonobj) throws Exception {		
		if(editmap.get("id")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("id", editmap.get("id"));
		}
	}
	public static void updateName(JSONObject jsonobj) throws Exception {		
		if(editmap.get("name")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("name", editmap.get("name"));
		}
	}
	public static void updateapplicationName(JSONObject jsonobj) throws Exception {		
		if(editmap.get("applicationName")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("applicationName", editmap.get("applicationName"));
		}
	}
	public static void updateentityId(JSONObject jsonobj) throws Exception {		
		if(editmap.get("entityId")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("entityId", editmap.get("entityId"));
		}
	}
	public static void updateactive(JSONObject jsonobj) throws Exception {		
		if(editmap.get("active")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("active", editmap.get("active"));
		}
	}

	public static void updatebaseURL(JSONObject jsonobj) throws Exception {		
		if(editmap.get("baseURL")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("baseURL", editmap.get("baseURL"));
		}
	}

	public static void updateloggingMode(JSONObject jsonobj) throws Exception {		
		if(editmap.get("loggingMode")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("loggingMode", editmap.get("loggingMode"));
		}
	}
	public static void updatelicenseConnectionGroup(JSONObject jsonobj) throws Exception {		
		if(editmap.get("licenseConnectionGroup")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).put("licenseConnectionGroup", editmap.get("licenseConnectionGroup"));
		}
	}

	public static void updatevirtualEntityIds(JSONObject jsonobj) throws Exception {		
		//VirtualEntityIds - no changes comes for virtualEntityIds Array 
	}

	//---------------------------------------------------------------------ContactInfo -------------------------------------------------------------------------------------------
	public static void updatecontactInfo_company(JSONObject jsonobj) throws Exception {		
		if(editmap.get("company")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("contactInfo").put("company", editmap.get("company"));
		}
	}

	public static void updatecontactInfo_firstName(JSONObject jsonobj) throws Exception {		
		if(editmap.get("firstName")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("contactInfo").put("firstName", editmap.get("firstName"));
		}
	}

	public static void updatecontactInfo_lastName(JSONObject jsonobj) throws Exception {		
		if(editmap.get("lastName")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("contactInfo").put("lastName", editmap.get("lastName"));
		}
	}

	public static void updatecontactInfo_phone(JSONObject jsonobj) throws Exception {		
		if(editmap.get("phone")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("contactInfo").put("phone", editmap.get("phone"));
		}
	}

	public static void updatecontactInfo_email(JSONObject jsonobj) throws Exception {		
		if(editmap.get("email")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("contactInfo").put("email", editmap.get("email"));
		}
	}

	//--------------------------------------------------------- Credentials -> Certs[] ----------------------------------------------------------------------------------------------

	public static void updateCred_Certs(JSONObject jsonobj) throws Exception {	
		JSONArray certs = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("credentials").getJSONArray("certs");
		for(int i=0;i<=certs.length();i++) {
			if(editmap.get("primaryVerificationCert_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("primaryVerificationCert").put("primaryVerificationCert", editmap.get("primaryVerificationCert_"+i+""));
			}
			
			if(editmap.get("secondaryVerificationCert_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("secondaryVerificationCert").put("secondaryVerificationCert", editmap.get("secondaryVerificationCert_"+i+""));
			}
			if(editmap.get("encryptionCert_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("encryptionCert").put("encryptionCert", editmap.get("encryptionCert_"+i+""));
			}
			if(editmap.get("certViewid_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("id", editmap.get("certViewid_"+i+""));
			}
			if(editmap.get("serialNumber_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("serialNumber",  editmap.get("serialNumber_"+i+""));
			}
			if(editmap.get("subjectDN_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("subjectDN", editmap.get("subjectDN_"+i+""));
			}
			if(editmap.get("issuerDN_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("issuerDN", editmap.get("issuerDN_"+i+""));
			}
			if(editmap.get("validFrom_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("validFrom", editmap.get("validFrom_"+i+""));
			}
			if(editmap.get("expires_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("expires", editmap.get("expires_"+i+""));
			}
			if(editmap.get("keyAlgorithm_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("keyAlgorithm", editmap.get("keyAlgorithm_"+i+""));
			}
			if(editmap.get("keySize_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("keySize", editmap.get("keySize_"+i+""));
			}
			if(editmap.get("signatureAlgorithm_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("signatureAlgorithm", editmap.get("signatureAlgorithm_"+i+""));
			}
			if(editmap.get("version_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("version", editmap.get("version_"+i+""));
			}
			if(editmap.get("md5Fingerprint_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("md5Fingerprint", editmap.get("md5Fingerprint_"+i+""));
			}
			if(editmap.get("sha1Fingerprint_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("sha1Fingerprint", editmap.get("sha1Fingerprint_"+i+""));
			}
			if(editmap.get("sha256Fingerprint_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("sha256Fingerprint", editmap.get("sha256Fingerprint_"+i+""));
			}
			if(editmap.get("status_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("certView").put("status", editmap.get("status_"+i+""));
			}
			if(editmap.get("fileData_"+i+"")!=null) {
				certs.getJSONObject(i).getJSONObject("x509File").put("fileData", editmap.get("fileData_"+i+""));
			}
		}
	}
//----------------------------------------------------------------   credentials -> signingSettings---------------------------------------------------------------------------------------------------------

	public static void updatesigningSettings_signingKeyPairRef_id(JSONObject jsonobj) throws Exception {		
		if(editmap.get("signingKeyPairRef_id")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("credentials").getJSONObject("signingSettings").getJSONObject("signingKeyPairRef").put("id",editmap.get("signingKeyPairRef_id"));
		}
	}
	public static void removesigningSettings_signingKeyPairRef_location(JSONObject jsonobj) throws Exception {		
		if(editmap.get("signingKeyPairRef_location")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("credentials").getJSONObject("signingSettings").getJSONObject("signingKeyPairRef").remove("signingKeyPairRef_location");
		}
	}

	public static void updatesigningSettings_includeCertInSignature(JSONObject jsonobj) throws Exception {		
		if(editmap.get("includeCertInSignature")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("credentials").getJSONObject("signingSettings").put("includeCertInSignature",editmap.get("includeCertInSignature"));
		}
	}

	public static void updatesigningSettings_includeRawKeyInSignature(JSONObject jsonobj) throws Exception {		
		if(editmap.get("includeRawKeyInSignature")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("credentials").getJSONObject("signingSettings").put("includeRawKeyInSignature",editmap.get("includeRawKeyInSignature"));
		}
	}

	public static void updatesigningSettings_algorithm(JSONObject jsonobj) throws Exception {		
		if(editmap.get("algorithm")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("credentials").getJSONObject("signingSettings").put("algorithm",editmap.get("algorithm"));
		}
	}
	//----------------------------------------------------------------  spBrowserSso ---------------------------------------------------------------------------------------------------------

	public static void updatespBrowserSso_protocol(JSONObject jsonobj) throws Exception {		
		if(editmap.get("protocol")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").put("protocol",editmap.get("protocol"));
		}
	}

	public static void updatespBrowserSso_signAssertions(JSONObject jsonobj) throws Exception {		
		if(editmap.get("signAssertionsflag")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").put("signAssertions",editmap.get("signAssertionsflag"));
		}
	}

	public static void updatespBrowserSso_spSamlIdentityMapping(JSONObject jsonobj) throws Exception {		
		if(editmap.get("spSamlIdentityMapping")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").put("spSamlIdentityMapping",editmap.get("spSamlIdentityMapping"));
		}
	}

	public static void updatespBrowserSso_requireSignedAuthnRequests(JSONObject jsonobj) throws Exception {		
		if(editmap.get("requireSignedAuthnRequests")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").put("requireSignedAuthnRequests",editmap.get("requireSignedAuthnRequests"));
		}
	}

	public static void updatespBrowserSso_enabledProfiles(JSONObject jsonobj) throws Exception {

		JSONArray enabledProfiles = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("enabledProfiles");
		for(int i=0;i<=enabledProfiles.length()-1;i++) {
			if(editmap.get("enabledProfiles_"+i+"")!=null) {
				enabledProfiles.put(i, editmap.get("enabledProfiles_"+i+""));
			}
		}
	}

	public static void updatespBrowserSso_incomingBindings(JSONObject jsonobj) throws Exception {		
		if(editmap.get("incomingBindings")!=null) {
			JSONArray incomingBindings = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("incomingBindings");
			incomingBindings.put(0, editmap.get("incomingBindings"));		
		}
	}

	public static void updatespBrowserSso_ssoServiceEndpoints(JSONObject jsonobj) throws Exception {		
		JSONArray ssoServiceEndpoints = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("ssoServiceEndpoints");
		for(int i=0;i<=ssoServiceEndpoints.length()-1;i++)	{
			if(editmap.get("ssoServiceEndpoints_"+i+"_binding")!=null){	
				ssoServiceEndpoints.getJSONObject(i).put("binding",editmap.get("ssoServiceEndpoints_"+i+"_binding"));			 
			}
			if(editmap.get("ssoServiceEndpoints_"+i+"_url")!=null){	
				ssoServiceEndpoints.getJSONObject(i).put("url",editmap.get("ssoServiceEndpoints_"+i+"_url"));			 
			}
			if(editmap.get("ssoServiceEndpoints_"+i+"_isDefault")!=null){	
				ssoServiceEndpoints.getJSONObject(i).put("isDefault",editmap.get("ssoServiceEndpoints_"+i+"isDefault"));			 
			}
			if(editmap.get("ssoServiceEndpoints_"+i+"_index")!=null){	
				ssoServiceEndpoints.getJSONObject(i).put("index",editmap.get("ssoServiceEndpoints_"+i+"_index"));			 
			}
		}
	}

	public static void updatespBrowserSso_assertionLifetime(JSONObject jsonobj) throws Exception {		
		if(editmap.get("minutesBefore")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONObject("assertionLifetime").put("minutesBefore",editmap.get("minutesBefore"));
		}
		if(editmap.get("minutesAfter")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONObject("assertionLifetime").put("minutesAfter",editmap.get("minutesAfter"));
		}
	}

	public static void updatespBrowserSso_encryptionPolicy(JSONObject jsonobj) throws Exception {		
		if(editmap.get("encryptAssertion")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONObject("encryptionPolicy").put("encryptAssertion",editmap.get("encryptAssertion"));
		}
		if(editmap.get("encryptSloSubjectNameId")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONObject("encryptionPolicy").put("encryptSloSubjectNameId",editmap.get("encryptSloSubjectNameId"));
		}
		if(editmap.get("sloSubjectNameIDEncrypted")!=null) {
			jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONObject("encryptionPolicy").put("sloSubjectNameIDEncrypted",editmap.get("sloSubjectNameIDEncrypted"));
		}

		JSONArray encryptedAttributes =	jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONObject("encryptionPolicy").getJSONArray("encryptedAttributes");
		for(int i=0;i<=encryptedAttributes.length()-1;i++)	{
			if(editmap.get("encryptedAttributes")!=null) {
				//Empty
				encryptedAttributes.put("");
			}
		}
	}

	public static void updatespBrowserSso_attributeContract_coreAttributes(JSONObject jsonobj) throws Exception {
		JSONArray coreAttributes = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONObject("attributeContract").getJSONArray("coreAttributes");
		for(int i=0;i<=coreAttributes.length();i++) {
			if(editmap.get("coreAttributes_name_"+i+"")!=null) {
				coreAttributes.getJSONObject(i).put("name",editmap.get("coreAttributes_name_"+i+""));
				coreAttributes.getJSONObject(i).put("nameFormat",editmap.get("coreAttributes_nameFormat_"+i+""));	
			}
		}
	}
	public static void updatespBrowserSso_attributeContract_extendedAttributes(JSONObject jsonobj) throws Exception {
		JSONArray extendedAttributes = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONObject("attributeContract").getJSONArray("extendedAttributes");
		for(int i=0;i<=extendedAttributes.length();i++) {
			if(editmap.get("extendedAttributes_name_"+i+"")!=null) {
				extendedAttributes.getJSONObject(i).put("name",editmap.get("extendedAttributes_name_"+i+""));
				extendedAttributes.getJSONObject(i).put("nameFormat",editmap.get("extendedAttributes_nameFormat_"+i+""));	
			}
		}
	}

	public static void updatespBrowserSso_adapterMappings_attributeSources(JSONObject jsonobj) throws Exception {
		JSONArray adapterMappings = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("adapterMappings");
		for(int i=0;i<=adapterMappings.length();i++) {	
			if(editmap.get("attributeSources")!=null) {
				JSONArray attributeSources = adapterMappings.optJSONArray(i);			
				attributeSources.put("");	
			}
		}
	}
	public static void updatespBrowserSso_adapterMappings_attributeContractFulfillment(JSONObject jsonobj) throws Exception {
		JSONArray adapterMappings = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("adapterMappings");
		for(int i=0;i<=adapterMappings.length();i++) {	
			if(editmap.get("SessionDuration_type_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("https://aws.amazon.com/SAML/Attributes/SessionDuration").getJSONObject("source").put("type",editmap.get("SessionDuration_type_"+i+""));
			}
			if(editmap.get("SessionDuration_value_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("https://aws.amazon.com/SAML/Attributes/SessionDuration").put("value",editmap.get("SessionDuration_value_"+i+""));
			}
			if(editmap.get("urn_oid1_type_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("urn:oid:1.3.6.1.4.1.5923.1.1.1.1").getJSONObject("source").put("type",editmap.get("urn_oid1_type_"+i+""));
			}
			if(editmap.get("urn_oid1_value_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("urn:oid:1.3.6.1.4.1.5923.1.1.1.1").put("value",editmap.get("urn_oid1_value_"+i+""));
			}
			if(editmap.get("RoleSessionName_type_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("https://aws.amazon.com/SAML/Attributes/RoleSessionName").getJSONObject("source").put("type",editmap.get("RoleSessionName_type_"+i+""));
			}
			if(editmap.get("RoleSessionName_value_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("https://aws.amazon.com/SAML/Attributes/RoleSessionName").put("value",editmap.get("RoleSessionName_value_"+i+""));
			}
			if(editmap.get("Role_type_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("https://aws.amazon.com/SAML/Attributes/Role").getJSONObject("source").put("type",editmap.get("Role_type_"+i+""));
			}
			if(editmap.get("Role_value_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("https://aws.amazon.com/SAML/Attributes/Role").put("value",replaceValueAsPerEnv(jsonobj,i));
			}
			if(editmap.get("urn_oid2_type_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("urn:oid:2.5.4.3").getJSONObject("source").put("type",editmap.get("urn_oid2_type_"+i+""));
			}
			if(editmap.get("urn_oid2_value_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("urn:oid:2.5.4.3").put("value",editmap.get("urn_oid2_value_"+i+""));
			}
			if(editmap.get("SAML_Subject_type_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("SAML_SUBJECT").getJSONObject("source").put("type",editmap.get("SAML_Subject_type_"+i+""));
			}
			if(editmap.get("SAML_Subject_value_"+i+"")!=null) {
				adapterMappings.getJSONObject(i).getJSONObject("SAML_SUBJECT").put("value",editmap.get("SAML_Subject_value_"+i+""));
			}
		}
	}

	private static String replaceValueAsPerEnv(JSONObject jsonobj,int adaptermappings_objectNum) throws Exception {		
		String value =jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("adapterMappings").getJSONObject(adaptermappings_objectNum).getJSONObject("attributeContractFulfillment").getJSONObject("https://aws.amazon.com/SAML/Attributes/Role").getString("value");
		return value.toString().replaceAll("ping-+"+editmap.get("FromEnv")+"", "ping-+"+editmap.get("ToEnv")+"");	
	}

	public static void updatespBrowserSso_adapterMappings_issuanceCriteria(JSONObject jsonobj) throws Exception {
		JSONArray adapterMappings = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("adapterMappings");
		for(int i=0;i<=adapterMappings.length();i++) {	
			if(editmap.get("issuanceCriteria_conditionalCriteria_"+i+"")!=null) {
				JSONArray conditionalCriteria = adapterMappings.getJSONObject(i).getJSONObject("issuanceCriteria").optJSONArray("conditionalCriteria");	
				conditionalCriteria.put("");	 // empty String
			}
		}
	}

	public static void updatespBrowserSso_adapterMappings_idpAdapterRef(JSONObject jsonobj) throws Exception {
		JSONArray adapterMappings = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("adapterMappings");
		for(int i=0;i<=adapterMappings.length();i++) {	
			if(editmap.get("idpAdapterRef_id"+i+"")!=null) {
				/*EnvValues env = dataStoreMap.get("Launcher");
				if(dec == et) {
					env.getEt();
				}else if(.adapterMappings.) {
					env.getUt();
				}*/
				adapterMappings.getJSONObject(i).getJSONObject("idpAdapterRef").put("id","idpAdapterRef_id"+i+"");	
				adapterMappings.getJSONObject(i).getJSONObject("idpAdapterRef").remove("location");	
			}
			if(editmap.get("restrictVirtualEntityIds"+i+"")!=null) {
				adapterMappings.getJSONObject(i).put("restrictVirtualEntityIds", editmap.get("restrictVirtualEntityIds"+i+""));	
			}
			if(editmap.get("restrictedVirtualEntityIds"+i+"")!=null) {
				JSONArray restrictedVirtualEntityIds = adapterMappings.getJSONObject(i).optJSONArray("restrictedVirtualEntityIds");	
				restrictedVirtualEntityIds.put("");
			}
		}
	}

	public static void updatespBrowserSso_authenticationPolicyContractAssertionMappings(JSONObject jsonobj) throws Exception {
		JSONArray authenticationPolicyContractAssertionMappings = jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("spBrowserSso").getJSONArray("authenticationPolicyContractAssertionMappings");
		for(int i=0;i<=authenticationPolicyContractAssertionMappings.length();i++) {	
			if(editmap.get("authenticationPolicyContractAssertionMappings")!=null) {					
				authenticationPolicyContractAssertionMappings.put("");	 // empty String
			}
		}
	}


	public static void updateJSON(JSONObject jsonobj) throws Exception {
		updateType(jsonobj);
		updateid(jsonobj);
		updateName(jsonobj);
		updateapplicationName(jsonobj);
		updateentityId(jsonobj);
		updateactive(jsonobj);
		updatebaseURL(jsonobj);
		updateloggingMode(jsonobj);
		updatelicenseConnectionGroup(jsonobj);
		updatevirtualEntityIds(jsonobj);
		updatecontactInfo_company(jsonobj);
		updatecontactInfo_firstName(jsonobj);
		updatecontactInfo_lastName(jsonobj);
		updatecontactInfo_phone(jsonobj);
		updatecontactInfo_email(jsonobj);
		updateCred_Certs(jsonobj);
		updatesigningSettings_signingKeyPairRef_id(jsonobj);
		removesigningSettings_signingKeyPairRef_location(jsonobj);
		updatesigningSettings_includeCertInSignature(jsonobj);
		updatesigningSettings_includeRawKeyInSignature(jsonobj);
		updatesigningSettings_algorithm(jsonobj);	
		updatespBrowserSso_protocol(jsonobj);
		updatespBrowserSso_signAssertions(jsonobj);
		updatespBrowserSso_spSamlIdentityMapping(jsonobj);
		updatespBrowserSso_requireSignedAuthnRequests(jsonobj);
		updatespBrowserSso_enabledProfiles(jsonobj);
		updatespBrowserSso_incomingBindings(jsonobj);
		updatespBrowserSso_ssoServiceEndpoints(jsonobj);
		updatespBrowserSso_assertionLifetime(jsonobj);
		updatespBrowserSso_encryptionPolicy(jsonobj);
		updatespBrowserSso_attributeContract_coreAttributes(jsonobj);
		updatespBrowserSso_attributeContract_extendedAttributes(jsonobj);
		updatespBrowserSso_adapterMappings_attributeSources(jsonobj);
		updatespBrowserSso_adapterMappings_attributeContractFulfillment(jsonobj);
		updatespBrowserSso_adapterMappings_issuanceCriteria(jsonobj);
		updatespBrowserSso_adapterMappings_idpAdapterRef(jsonobj);
		updatespBrowserSso_authenticationPolicyContractAssertionMappings(jsonobj);

	}
}

