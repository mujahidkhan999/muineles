package MVP;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class DataStore {

	public static Map<String,EnvValues> getDataStoreMap() {
		try {
			Map<String,EnvValues> map = new HashMap<String,EnvValues>();
			FileInputStream inputstream = new FileInputStream(new File("JSONEditorValues.xlsx"));	

			Workbook workbook = new XSSFWorkbook(inputstream);
			Sheet firstSheet = workbook.getSheetAt(1);

			for(int i=1;i<=firstSheet.getLastRowNum();i++)
			{
				Row row = firstSheet.getRow(i);
				if(row !=null) {
					String datastoreId = ExcelConfig.getCellValue(row,0);
					String ut = ExcelConfig.getCellValue(row,1);
					String st = ExcelConfig.getCellValue(row, 2);
					String et = ExcelConfig.getCellValue(row, 3);
					String prod = ExcelConfig.getCellValue(row,4);
					EnvValues env = new EnvValues(datastoreId,ut,st,et,prod);
					map.put(datastoreId,env);	 

				}
			}
			workbook.close();
			inputstream.close();
			return map;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public static void main(String[] args) throws Exception {
		Map<String,EnvValues> map = getDataStoreMap();
		for (Map.Entry entry : map.entrySet()) {
			System.out.println(entry.getKey()+""+entry.getValue());

		}
	}
}


