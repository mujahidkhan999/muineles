
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class JSONPUT extends GetJSON{	
	public static void main(String[] args) throws Exception  {		
		Map<String,String> map = new HashMap<String,String> ();
		map = ExcelConfig.readExcel();
		URL url = new URL(map.get("PUT-URL"));
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();		
		connection.setDoOutput(true);
		connection.setRequestProperty("Authorization", map.get("Authorization"));
		connection.setRequestMethod("PUT");
		connection.setRequestProperty("Content-Type", map.get("Content-Type"));
		connection.setRequestProperty("X-Xsrf-Header",map.get("X-Xsrf-Header"));	
		String absolutepath = GetJSON.Filepath();
		String content = new String(Files.readAllBytes(Paths.get(absolutepath)));
		OutputStreamWriter osw = new OutputStreamWriter(connection.getOutputStream());
		osw.write(content);
		osw.flush();
		osw.close();
		System.err.println(connection.getResponseCode());
		if(connection.getResponseCode()==200) {
			System.out.println("\n" );
			System.out.println(" PUT request is successful");
		}
	}
}
