import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

public class GetJSON {

	static Map<String,String> map = new HashMap<String,String> ();

	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	//Get Json from a https URL by passing required headers
	public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {		
		URL u = new URL(url);		
		HttpURLConnection con = (HttpURLConnection) u.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);
		con.setRequestProperty("entityId", map.get("entityId"));
		con.setRequestProperty("Authorization", map.get("Authorization"));
		con.setRequestProperty("Content-Type", map.get("Content-Type"));	
		con.setRequestProperty("Accept", map.get("Accept"));
		con.setRequestMethod("GET");
		con.setRequestProperty("X-Xsrf-Header", map.get("X-Xsrf-Header"));
		BufferedReader rd = new BufferedReader(new InputStreamReader(con.getInputStream(), Charset.forName("UTF-8")));
		String jsonText = readAll(rd);
		JSONObject json = new JSONObject(jsonText);
		return json;
	}	 
	public static void main(String args[]) throws JSONException, Exception {
		map = ExcelConfig.readExcel(); //Reads the Excel Config file and retreives the parameters needed to get json from https URL
		JSONObject jsonobj   = readJsonFromUrl(map.get("GET-URL"));		
		deserializeJSON(jsonobj);
		// Writing the JSON object content to a file UTAmazonExportGet.json
//		System.out.println(jsonobj.toString());	
		String absoluteFilePath = Filepath();
		try (FileWriter file = new FileWriter(absoluteFilePath)) {
			file.write(jsonobj.toString());
			file.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static String Filepath() {
		String filename = "UTAmazonExportGet.json";
		String workingDirectory = System.getProperty("user.dir");
		String absoluteFilePath = "";
		absoluteFilePath = workingDirectory + File.separator + filename;
		return absoluteFilePath;

	}
	
	public static void deserializeJSON(JSONObject jsonobj) {		
		String json = jsonobj.toString();
		System.out.println(json);
//		Type listType = new TypeToken<ArrayList<JSONKeyAttributes>>() {}.getType();
		JSONKeyAttributes attributes = new Gson().fromJson(json,JSONKeyAttributes.class);
		System.out.println(attributes);
		
		
		
	}
}

