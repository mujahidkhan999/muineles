package JSONEDIT;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

public class JsonParserEditor {

	private static Map<String, String> map;

	public static void main(String[] args) {
		try {
			map = ExcelConfig.readExcel();

			JSONObject jsonobj = readJsonFromUrl(map.get("GET-URL"));

			updateName(jsonobj);
			updateId(jsonobj);
			updateEntityId(jsonobj);
			udapteCeritificateFileData(jsonobj);

			// Writing the JSON object content to a file UTAmazonExportGet.json
			String absoluteFilePath = Filepath();
			FileWriter file = new FileWriter(absoluteFilePath);
			file.write(jsonobj.toString());
			file.flush();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void udapteCeritificateFileData(JSONObject jsonobj) {
		jsonobj.getJSONArray("items").getJSONObject(0).getJSONObject("credentials").getJSONArray("certs")
				.getJSONObject(0).getJSONObject("x509File").put("fileData", "worst big file");
	}

	private static void updateEntityId(JSONObject jsonobj) {
		jsonobj.getJSONArray("items").getJSONObject(0).put("entityId", "update entoty from excel");

	}

	private static void updateId(JSONObject jsonobj) {
		jsonobj.getJSONArray("items").getJSONObject(0).put("id", "update id from excel");

	}

	private static void updateName(JSONObject jsonobj) {
		jsonobj.getJSONArray("items").getJSONObject(0).put("name", "update name from excel");

	}

	// Get Json from a https URL by passing required headers
	public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
		URL u = new URL(url);
		HttpURLConnection con = (HttpURLConnection) u.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);
		con.setRequestProperty("entityId", map.get("entityId"));
		con.setRequestProperty("Authorization", map.get("Authorization"));
		con.setRequestProperty("Content-Type", map.get("Content-Type"));
		con.setRequestProperty("Accept", map.get("Accept"));
		con.setRequestMethod("GET");
		con.setRequestProperty("X-Xsrf-Header", map.get("X-Xsrf-Header"));
		// BufferedReader rd = new BufferedReader(new
		// InputStreamReader(con.getInputStream(), Charset.forName("UTF-8")));

		BufferedReader rd = new BufferedReader(new FileReader("JSONEDIT.json"));
		String jsonText = readAll(rd);
		JSONObject json = new JSONObject(jsonText);
		return json;
	}

	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public static String Filepath() {
		String filename = "UTAmazonExportGet.json";
		String workingDirectory = System.getProperty("user.dir");
		String absoluteFilePath = "";
		absoluteFilePath = workingDirectory + File.separator + filename;
		return absoluteFilePath;

	}

}
