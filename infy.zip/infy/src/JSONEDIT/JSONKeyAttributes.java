package JSONEDIT;

import java.util.Arrays;

public class JSONKeyAttributes {
	private String type;
	private String id;
	private String name;
	private String entityid;
	private boolean active;
	private String baseURL;
	private String loggingMode;
	private String virtualEntityIds[];
	private String licenseConnectionGroup;
	private String contactInfo[];

	/*
	 * private List<credentials> credentials; private List<spBrowserSso>
	 * spBrowserSso;
	 */
	public JSONKeyAttributes() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEntityid() {
		return entityid;
	}

	public void setEntityid(String entityid) {
		this.entityid = entityid;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getBaseURL() {
		return baseURL;
	}

	public void setBaseURL(String baseURL) {
		this.baseURL = baseURL;
	}

	public String getLoggingMode() {
		return loggingMode;
	}

	public void setLoggingMode(String loggingMode) {
		this.loggingMode = loggingMode;
	}

	public String[] getVirtualEntityIds() {
		return virtualEntityIds;
	}

	public void setVirtualEntityIds(String[] virtualEntityIds) {
		this.virtualEntityIds = virtualEntityIds;
	}

	public String getLicenseConnectionGroup() {
		return licenseConnectionGroup;
	}

	public void setLicenseConnectionGroup(String licenseConnectionGroup) {
		this.licenseConnectionGroup = licenseConnectionGroup;
	}

	public String[] getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(String[] contactInfo) {
		this.contactInfo = contactInfo;
	}

	@Override
	public String toString() {
		return "JSONKeyAttributes [type=" + type + ", id=" + id + ", name=" + name + ", entityid=" + entityid
				+ ", active=" + active + ", baseURL=" + baseURL + ", loggingMode=" + loggingMode + ", virtualEntityIds="
				+ Arrays.toString(virtualEntityIds) + ", licenseConnectionGroup=" + licenseConnectionGroup
				+ ", contactInfo=" + Arrays.toString(contactInfo) + "]";
	}

	/*
	 * public List<credentials> getCredentials() { return credentials; }
	 * 
	 * public void setCredentials(List<credentials> credentials) { this.credentials
	 * = credentials; }
	 * 
	 * public List<spBrowserSso> getSpBrowserSso() { return spBrowserSso; }
	 * 
	 * public void setSpBrowserSso(List<spBrowserSso> spBrowserSso) {
	 * this.spBrowserSso = spBrowserSso; }
	 * 
	 * @Override public String toString() { return "JSONKeyAttributes [type=" + type
	 * + ", id=" + id + ", name=" + name + ", entityid=" + entityid + ", active=" +
	 * active + ", baseURL=" + baseURL + ", loggingMode=" + loggingMode +
	 * ", virtualEntityIds=" + Arrays.toString(virtualEntityIds) +
	 * ", licenseConnectionGroup=" + licenseConnectionGroup + ", contactInfo=" +
	 * Arrays.toString(contactInfo) + ", credentials=" + credentials +
	 * ", spBrowserSso=" + spBrowserSso + "]"; }
	 */

}
