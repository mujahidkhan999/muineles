import java.util.List;

public class Cred {
	
	private List<Values> values;

	public Cred(List<Values> values) {
		this.values = values;
	}

	public List<Values> getValues() {
		return values;
	}

	public void setValues(List<Values> values) {
		this.values = values;
	}

	@Override
	public String toString() {
		return "Cred [values=" + values + "]";
	}
	
	 

}
