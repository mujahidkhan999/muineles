

import java.util.List;

public class Items {
	
	private List<Resp> items;

	public Items(List<Resp> items) {
		this.items = items;
	}

	public List<Resp> getItems() {
		return items;
	}

	public void setItems(List<Resp> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "Items [items=" + items + "]";
	}
	
	

}
