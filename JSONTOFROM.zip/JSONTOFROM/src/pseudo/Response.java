package pseudo;

import java.io.FileReader;
import java.util.List;

import com.google.gson.Gson;

public class Response {

	Data data;

	public Response(Data data) {
		this.data = data;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Response [data=" + data + "]";
	}

	public static void main(String[] args) throws Exception {
		Gson gson = new Gson();
		Response response = gson.fromJson(new FileReader("I:\\nested.json"), Response.class);
		System.out.println("Response :" + response);
		Data data = response.getData();
		System.out.println("Data :" + data);
		List<ID> ids = data.getId();
		for (ID id : ids) {
			System.out.println("ID :" + id);
			System.out.println("Stuff :" + id.getStuff());
			List<List<Integer>> values = id.getValues();
			for (List<Integer> list : values) {
				for (Integer integer : list) {
					System.out.println("values :" + integer);
				}
			}
			System.out.println("OtherStuff :" + id.getOtherStuff());
		}

	}

}

class Data {
	List<ID> id;

	public Data(List<ID> id) {
		this.id = id;
	}

	public List<ID> getId() {
		return id;
	}

	public void setId(List<ID> id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Data [id=" + id + "]";
	}

}

class ID {
	Stuff stuff;
	List<List<Integer>> values;
	String otherStuff;

	public ID(Stuff stuff, List<List<Integer>> values, String otherStuff) {
		this.stuff = stuff;
		this.values = values;
		this.otherStuff = otherStuff;
	}

	public Stuff getStuff() {
		return stuff;
	}

	public void setStuff(Stuff stuff) {
		this.stuff = stuff;
	}

	public List<List<Integer>> getValues() {
		return values;
	}

	public void setValues(List<List<Integer>> values) {
		this.values = values;
	}

	public String getOtherStuff() {
		return otherStuff;
	}

	public void setOtherStuff(String otherStuff) {
		this.otherStuff = otherStuff;
	}

	@Override
	public String toString() {
		return "ID [stuff=" + stuff + ", values=" + values + ", otherStuff=" + otherStuff + "]";
	}

}

class Stuff {

}