

import java.util.List;

public class Resp {
	


		private String type;
		private String id;
		private String name;
		private String entityId;
		private String active;
		private Cred credentials;
		private String custom;
		public Resp(String type, String id, String name, String entityId, String active, Cred credentials,
				String custom) {
			this.type = type;
			this.id = id;
			this.name = name;
			this.entityId = entityId;
			this.active = active;
			this.credentials = credentials;
			this.custom = custom;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEntityId() {
			return entityId;
		}
		public void setEntityId(String entityId) {
			this.entityId = entityId;
		}
		public String getActive() {
			return active;
		}
		public void setActive(String active) {
			this.active = active;
		}
		public Cred getCredentials() {
			return credentials;
		}
		public void setCredentials(Cred credentials) {
			this.credentials = credentials;
		}
		public String getCustom() {
			return custom;
		}
		public void setCustom(String custom) {
			this.custom = custom;
		}
		@Override
		public String toString() {
			return "Resp [type=" + type + ", id=" + id + ", name=" + name + ", entityId=" + entityId + ", active="
					+ active + ", credentials=" + credentials + ", custom=" + custom + "]";
		}
		
}
